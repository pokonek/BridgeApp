<div style="width:80vw;height:40em;margin: auto;">
    <canvas id="chart-canvas"></canvas>
</div>