<?php 
$con = mysqli_connect('localhost','root',''); 
$con->set_charset("utf8");
mysqli_select_db($con, 'csv_db 6'); 
?>